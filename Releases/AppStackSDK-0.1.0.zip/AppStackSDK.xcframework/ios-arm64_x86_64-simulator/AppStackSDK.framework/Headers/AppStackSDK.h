#import <Foundation/Foundation.h>

//! Project version number for AppStackSDK.
FOUNDATION_EXPORT double AppStackSDKVersionNumber;

//! Project version string for AppStackSDK.
FOUNDATION_EXPORT const unsigned char AppStackSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppStackSDK/PublicHeader.h>


